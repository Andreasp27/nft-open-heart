<?php

$md5image1 = md5(file_get_contents("images/1650879751.png"));
$md5image2 = md5(file_get_contents("images/1650879752.png"));
if ($md5image1 == $md5image2) {
    echo 1 . " md5 1: " . $md5image1;
}else{
    echo 0 . " md5 1: " . $md5image1;
}


?><?php /**PATH D:\dokumen\KULIAH\Semester 8\Pengembangan Aplikasi Mobile\Tugas\open-heart\nft-open-heart\open-heart\resources\views/compare.blade.php ENDPATH**/ ?>